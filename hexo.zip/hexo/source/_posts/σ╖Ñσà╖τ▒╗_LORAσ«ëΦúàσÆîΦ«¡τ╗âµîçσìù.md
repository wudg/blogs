---
title: 【工具类】LORA安装和训练指南｜高质量模特养成｜教你打造自己专属的迷人模特
date: 2023-03-25 15:13:00
tags: 
  - lora
categories: 
  - 好用工具类
keyword: "【工具类】LORA安装和训练指南｜高质量模特养成｜教你打造自己专属的迷人模特"
description: "【工具类】LORA安装和训练指南｜高质量模特养成｜教你打造自己专属的迷人模特"
cover: https://wudiguang.top/images/hexo/tools/cover-arthas.jpg
top_img: https://wudiguang.top/images/hexo/tools/cover-arthas.jpg
---

## 下载安装AUTOMATIC1111

1. 下载 Homebrew：/bin/bash -c "$(curl -fsSL <https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh>)"
2. 安装一些必须的软件包：brew install cmake protobuf rust python@3.10 git wget
3. 下载 AUTOMATIC1111 存储库：git clone <https://github.com/AUTOMATIC1111/stable-diffusion-webui>


## 下载一个基础模型

https://stable-diffusion-art.com/models/#Stable_diffusion_v15

https://civitai.com/models/6424/chilloutmix

https://civitai.com/models/7448/korean-doll-likeness