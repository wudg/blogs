---
title: 友情链接
date: 2018-06-07 22:17:49
type: "link"
---

{% flink %}
- class_name: 友情链接
  class_desc: 友情链接
  link_list:
    - name: 阮一峰的个人网站
      link: https://www.ruanyifeng.com/
      avatar: https://wudiguang.top/images/hexo/link/ruanyifeng.jpg
      descr: 科技爱好者
    - name: Hillyee-blog
      link: https://hillyee.github.io/
      avatar: https://wudiguang.top/images/hexo/blogger/hillyee.jpg
      descr: 前端爱好者

- class_name: 网站
  class_desc: 值得推荐的网站
  link_list:
    - name: 稀土掘金
      link: https://juejin.cn/
      avatar: https://wudiguang.top/images/hexo/link/logo-juejin.png
      descr: 掘金是面向全球中文开发者的技术内容分享与交流平台
{% endflink %}