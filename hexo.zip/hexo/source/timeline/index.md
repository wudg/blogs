---
title: 网站时间线记录
date: 2023-02-12 17:51:49
type: "link"
---

{% timeline 2023,color %}
<!-- timeline 1月 -->
网站建设
<!-- endtimeline -->
<!-- timeline 2月10日 -->
羊毛文档分享
<!-- endtimeline -->
<!-- timeline 2月20日 -->
图片统一使用nginx配置的静态图片链接，替换本地相对路径图片
<!-- endtimeline -->
{% endtimeline %}