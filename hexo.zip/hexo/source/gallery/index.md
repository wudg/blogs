<div class="gallery-group-main">
{% galleryGroup '日常' '日常照片' '/gallery/daily' 'https://wudiguang.top/images/hexo/daily/001.jpg' %}
{% galleryGroup '壁纸' '收藏的一些壁纸' '/gallery/gallery' 'https://wudiguang.top/images/hexo/gallery/1.jpg' %}
{% galleryGroup '教资(科目一)' '视频资料截图' '/gallery/teacher1' 'https://wudiguang.top/images/hexo/teacher2/cover-teacher.png' %}
{% galleryGroup '教资(科目二)' '视频资料截图' '/gallery/teacher2' 'https://wudiguang.top/images/hexo/teacher2/cover-teacher.png' %}
</div>